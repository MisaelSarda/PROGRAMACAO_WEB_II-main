@extends('layouts.app')

@section('content')
<div class="max-w-xl mx-auto bg-white p-6 mt-8 rounded shadow">
    <h1 class="text-2xl font-bold mb-6">Editar Região</h1>

    @if($errors->any())
        <div class="bg-red-100 text-red-800 px-4 py-2 rounded mb-4">
            <ul class="list-disc pl-4">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('regioes.update', $regiao) }}" method="POST" class="space-y-4">
        @csrf
        @method('PUT')

        <input type="text" name="nome" class="w-full p-2 rounded border" value="{{ old('nome', $regiao->nome) }}" required>

        <div class="flex justify-between">
            <a href="{{ route('regioes.index') }}" class="text-gray-600 hover:underline">← Voltar</a>
            <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">Atualizar</button>
        </div>
    </form>
</div>
@endsection
