@extends('layouts.app')

@section('content')
<div class="max-w-xl mx-auto bg-white p-6 mt-8 rounded shadow">
    <h1 class="text-2xl font-bold mb-6">Cadastrar Pessoa</h1>

    @if($errors->any())
        <div class="bg-red-100 text-red-800 px-4 py-2 rounded mb-4">
            <ul class="list-disc pl-4">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('pessoas.store') }}" method="POST" class="space-y-4">
        @csrf

        <input type="text" name="nome" placeholder="Nome" class="w-full p-2 rounded border" value="{{ old('nome') }}" required>
        <input type="email" name="email" placeholder="Email" class="w-full p-2 rounded border" value="{{ old('email') }}" required>
        <input type="text" name="telefone" placeholder="Telefone" class="w-full p-2 rounded border" value="{{ old('telefone') }}" required>

        <div class="flex justify-between">
            <a href="{{ route('pessoas.index') }}" class="text-gray-600 hover:underline">← Voltar</a>
            <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">
                Salvar
            </button>
        </div>
    </form>
</div>
@endsection
