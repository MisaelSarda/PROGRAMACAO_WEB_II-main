@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Lista de Documentos</h2>

    @if(session('success'))
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <a href="{{ route('documentos.create') }}"
       class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded mb-4 inline-block">
        + Novo Documento
    </a>

    <div class="overflow-x-auto bg-white shadow rounded-lg">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-700">Nome</th>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-700">Tipo</th>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-700">Validade</th>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-700">Pessoa</th>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-700">Região</th>
                    <th class="px-6 py-3 text-right text-sm font-medium text-gray-700">Ações</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @foreach($documentos as $documento)
                <tr>
                    <td class="px-6 py-4">{{ $documento->nome }}</td>
                    <td class="px-6 py-4">{{ $documento->tipo }}</td>
                    <td class="px-6 py-4">{{ \Carbon\Carbon::parse($documento->data_validade)->format('d/m/Y') }}</td>
                    <td class="px-6 py-4">{{ $documento->pessoa->nome }}</td>
                    <td class="px-6 py-4">{{ $documento->regiao->nome }}</td>
                    <td class="px-6 py-4 text-right">
                        <a href="{{ route('documentos.edit', $documento) }}" class="text-indigo-600 hover:underline mr-3">Editar</a>
