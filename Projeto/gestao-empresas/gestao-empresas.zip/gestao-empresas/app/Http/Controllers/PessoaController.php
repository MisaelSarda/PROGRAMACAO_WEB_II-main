<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pessoa;

class PessoaController extends Controller
{
    /**
     * Exibe o formulário de cadastro de pessoa
     */
    public function create()
    {
        return view('pessoas.create');
    }

    /**
     * Salva uma nova pessoa no banco
     */
    public function store(Request $request)
    {
        $request->validate([
            'nome' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'telefone' => 'nullable|string|max:20',
        ]);

        Pessoa::create($request->only('nome', 'email', 'telefone'));

        return redirect()
            ->route('pessoas.create')
            ->with('success', 'Pessoa cadastrada com sucesso!');
    }
    public function index()
{
    $pessoas = Pessoa::orderBy('id', 'desc')->get();
    return view('pessoas.index', compact('pessoas'));
}
}
