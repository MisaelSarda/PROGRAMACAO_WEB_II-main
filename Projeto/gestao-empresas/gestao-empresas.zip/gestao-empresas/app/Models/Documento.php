<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Documento extends Model
{
    use HasFactory;

    protected $fillable = ['nome', 'tipo', 'data_validade', 'arquivo', 'pessoa_id', 'regiao_id'];

    public function pessoa()
    {
        return $this->belongsTo(Pessoa::class);
    }

    public function regiao()
    {
        return $this->belongsTo(Regiao::class);
    }
}
