

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Cadastrar Nova Empresa</h1>

    <form action="<?php echo e(route('empresas.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('empresas.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <button type="submit" class="btn btn-success">Salvar</button>
        <a href="<?php echo e(route('empresas.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Misael\PROGRAMACAO_WEB_II-main\Projeto\gestao-empresas\resources\views/empresas/create.blade.php ENDPATH**/ ?>